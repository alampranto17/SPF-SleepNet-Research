# latexmk configuration for Overleaf
# Ensures bibtex is run when refs.bib changes
$pdf_mode = 1;              # 1 = pdflatex
$bibtex_use = 2;            # 2 = always run bibtex
$cleanup_includes_cusdep_generated = 1;
@default_files = ('main.tex');
