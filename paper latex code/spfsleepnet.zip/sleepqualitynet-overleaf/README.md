# SleepQualityNet — IEEE J-BHI Overleaf Template

A complete, upload-ready LaTeX project for an IEEE Journal of Biomedical and Health Informatics (J-BHI) submission targeting the **Special Issue on Explainable AI and Cognitive Computation in the Learning of Human Physiological Systems** (deadline 31 Aug 2026).

## Quick Start on Overleaf

1. **Download** the ZIP of this folder.
2. Go to [overleaf.com](https://www.overleaf.com) → **New Project** → **Upload Project** → drag-drop the ZIP.
3. The project opens with `main.tex` as the main document and pdfLaTeX as the compiler.
4. Click **Recompile**. The first build runs `pdflatex → bibtex → pdflatex → pdflatex` automatically.
5. You should see a ~10-page PDF with cover, abstract, 12 sections, 7 tables, 3 equations, 1 algorithm, 4 figures, and 24 references.

## Project Structure

```
sleepqualitynet-overleaf/
├── main.tex                  ← entry point (the paper)
├── refs.bib                  ← BibTeX references (24 entries)
├── IEEEtran.cls              ← official IEEE class file (v2.x)
├── IEEEtran.bst              ← official IEEE BibTeX style
├── .latexmkrc                ← latexmk config (auto-runs bibtex)
├── README.md                 ← this file
└── figures/
    ├── fig1_architecture.png      ← SleepQualityNet dual-path architecture
    ├── fig2_preprocessing.png     ← Preprocessing pipeline
    ├── fig3_eval_4panel.png       ← CM + ROC + PR + quality scatter
    └── fig4_counterfactual.png    ← Counterfactual delta-removal
```

## What's Inside main.tex

| Element | Count | Details |
|---|---|---|
| Sections | 12 + Appendix | Intro → Related → Dataset → Preproc → Architecture → Training → Eval → Ablation → XAI → Discussion → Limitations → Conclusion + Reproducibility Appendix |
| Tables | 7 | Dataset, Features, Hyperparameters, Headline Metrics, CV, Ablation, XAI Summary |
| Equations | 3 | Multi-task loss, BCE+pos_weight, Quality-label construction |
| Algorithm | 1 | Training loop with warmup+cosine + EMA + gradient accumulation |
| Figures | 4 | Architecture, Preprocessing, Eval 4-panel, Counterfactual |
| References | 24 | ISRUC, AASM, DeepSleepNet, U-Sleep, SleepTransformer, SHAP, attention, EMA, cosine, AdamW, Bland-Altman, McNemar, bootstrap, Cohen, Jain&Wallace, + 9 more |

## Placeholder Convention

Every spot that needs your input is wrapped in `\draftnote{...}` which renders as **[DRAFT: ...]** in red. Before final submission:

1. Find every `\draftnote{...}` (Overleaf: Ctrl+F → search "DRAFT").
2. Replace each with your real content.
3. Comment out or delete this line in the preamble to strip any remaining markers:
   ```latex
   \newcommand{\draftnote}[1]{\textcolor{red}{[\textbf{DRAFT:} #1]}}
   ```
   Replace with:
   ```latex
   \newcommand{\draftnote}[1]{}  % no-op, strips all markers
   ```

## Replacing the Placeholder Figures

The 4 PNGs in `figures/` are auto-generated placeholders. Replace each with your real publication figure (300 DPI, exported from your notebook's `outputs/` directory):

| Notebook Cell | Replace This File |
|---|---|
| Cell 11 (architecture diagram) | `figures/fig1_architecture.png` |
| Cell 14 (preprocessing pipeline) | `figures/fig2_preprocessing.png` |
| Cell 36 (4-panel evaluation) | `figures/fig3_eval_4panel.png` |
| Cell 61 (counterfactual) | `figures/fig4_counterfactual.png` |

Keep the same filenames and the LaTeX will pick them up automatically.

## Adding More References

Edit `refs.bib` and add new BibTeX entries. In `main.tex`, cite with `\cite{key}`. The IEEEtran bibliography style will format them automatically.

## Compilation Notes

- **Compiler:** pdfLaTeX (set in Menu → Compiler). The `IEEEtran.cls` works with pdfLaTeX, XeLaTeX, or LuaLaTeX.
- **Main document:** `main.tex` (set in Menu → Main document).
- **First compile is slow** (~30s) because Overleaf runs bibtex. Subsequent compiles are fast.
- **No external dependencies** — `IEEEtran.cls` and `IEEEtran.bst` are bundled in this project, so it works even on Overleaf's minimal TeX Live install.

## Submission Checklist (Before Submitting to J-BHI)

- [ ] All `\draftnote{...}` placeholders replaced with real content
- [ ] Author names and affiliations filled in
- [ ] Grant / funding acknowledgment added
- [ ] Related Work (Section II) written from the literature (currently a placeholder)
- [ ] Discussion (Section X) written (currently a placeholder)
- [ ] Acknowledgment section filled in
- [ ] All 4 placeholder figures replaced with real publication figures
- [ ] DOI added to the `\IEEEpubid` line
- [ ] PDF compiles without errors or warnings (except minor `Underfull \hbox` warnings, which are normal)
- [ ] Page count within J-BHI limits (~10 pages for a regular paper, ~13 for a survey)
- [ ] All references in `refs.bib` are cited at least once in the text
- [ ] Spell-check and grammar review

## License

The IEEEtran class and style files are provided by IEEE for manuscript preparation. The template structure, prose, and placeholder figures are provided as-is for your adaptation.
